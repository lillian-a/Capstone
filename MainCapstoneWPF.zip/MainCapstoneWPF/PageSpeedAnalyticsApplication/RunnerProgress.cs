﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageSpeedAnalyticsApplication
{
    public partial class RunnerProgress : Form
    {
        public bool runCSV = false;
        public const int DEFAULT_STEP = 5;

        public RunnerProgress()
        {
            InitializeComponent();
        }

        public bool Process(List<string> urls, string reportMethod)
        {
            UpdateStatus(10, "Validating Urls...");
            List<string> validUrls = PageSpeedCalculations.CheckIfUrlsValid(urls);
            int num_urls = validUrls.Count;
            int method = PageSpeedCalculations.ConvertReportMethod(reportMethod);
            int method_step = (method <= 1) ? 10 : 20;
            List<PageSpeedEntity> desktopResults = new List<PageSpeedEntity>(validUrls.Count);
            List<PageSpeedEntity> mobileResults = new List<PageSpeedEntity>(validUrls.Count);
            int i = 0;
            List<PageSpeedEntity> results = new List<PageSpeedEntity>(2);
            UpdateStatus(10, "Running services on urls...");
            foreach (string s in validUrls)
            {
                PageSpeedService pageSpeedService = new PageSpeedService();
                results = pageSpeedService.RunProcessUrl(s);
                desktopResults.Add(results[0]);
                mobileResults.Add(results[1]);
                i++;
            }
            int num = (runCSV) ? 60 : 50;
            UpdateStatus(num, "Creating reports...");
            PageSpeedReport.CreateReports(urls, desktopResults, mobileResults, PageSpeedCalculations.ConvertReportMethod(reportMethod));
            UpdateStatus(method_step, "Reports Created...");
            RunnerProgressBar1.Value = 100;
            this.Close();
            return true;
        }

        public bool ProcessFromCSV(string fileName, string filePath, string reportMethod)
        {
            // get urls
            runCSV = true;
            List<string> urlsFromCSV = PageSpeedCalculations.ParseCSV(filePath);
            IncreaseBar(10);
            Process(urlsFromCSV, reportMethod);
            return true;
        }

        private void RunnerProgress_Load(object sender, EventArgs e)
        {
            RunnerProgressBar1.Step = DEFAULT_STEP;
            RunnerProgressBar1.Value = 0;
            UpdateStatusLabel("Starting Process...");
        }

        private void UpdateStatus(int amt, string s)
        {
            IncreaseBar(amt);
            UpdateStatusLabel(s);
        }
        private void IncreaseBar(int amt)
        {
            int max = 100;
            int start = RunnerProgressBar1.Value;
            if (start + amt <= max)
                RunnerProgressBar1.Value = start + amt;
            else
                RunnerProgressBar1.Value = max;
        }

        private void UpdateStatusLabel(string s)
        {
            label1.Text = s;
        }
        
    }
}
