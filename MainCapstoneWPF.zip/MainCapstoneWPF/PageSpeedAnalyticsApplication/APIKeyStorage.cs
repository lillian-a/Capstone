﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageSpeedAnalyticsApplication
{
    class APIKeyStorage
    {
        public static string API_KEY = "AIzaSyDQnv3yeO5glJWfjs7TZuv3ecIQvGPxJNI";
        public static string APP_NAME = "PageSpeedOnline API Sample";
    }
}
