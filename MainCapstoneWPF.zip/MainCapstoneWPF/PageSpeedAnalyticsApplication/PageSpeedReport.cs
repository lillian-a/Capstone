﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageSpeedAnalyticsApplication
{
    class PageSpeedReport
    {
        /**
         * PATH NOTES FOR FILE SAVING
         * PATH NOTES FOR FILE SAVING
         * string s = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Documents");
         * // s = "C:\Users\Cat\Documents"
         * string s = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Documents","XYZ");
         * // s = "C:\Users\Cat\Documents\XYZ"
         * */

        /// CreateReports
        /// <summary>Runs create report processes</summary>
        /// <param name="urls">List of urls for report</param>
        /// <param name="deskResults">PageSpeedEntity List containing desktop results</param>
        /// <param name="mobileResults">PageSpeedEntity List containing mobile results</param>
        /// <param name="method">int indicating user's requested report method</param>
        public static void CreateReports(List<string> urls,
            List<PageSpeedEntity> deskResults,
            List<PageSpeedEntity> mobileResults, int method)
        {
            string[] header = GetHeaderString();
            string[,] rows = new string[urls.Count + 1, (header.Length)];
            for (int i = 0; i < header.Length; i++)
            {
                rows[0, i] = header[i];
            }
            int rowIndex = 1;
            int listIndex = 0;
            foreach (string s in urls)
            {
                // Date
                rows[rowIndex, 0] = DateTime.Today.ToString("d");
                // url
                rows[rowIndex, 1] = urls[listIndex];
                // title
                if (deskResults[listIndex].Result.Title == null || deskResults[listIndex].Result.Title == "")
                {
                    rows[rowIndex, 2] = "";
                }
                else
                {
                    rows[rowIndex, 2] = deskResults[listIndex].Result.Title;
                }
                rows[rowIndex, 3] = deskResults[listIndex].Score.ToString();
                rows[rowIndex, 4] = mobileResults[listIndex].Score.ToString();
                rows[rowIndex, 5] = deskResults[listIndex].Result.LoadingExperience.OverallCategory;
                rows[rowIndex, 6] = mobileResults[listIndex].Result.LoadingExperience.OverallCategory;
                rowIndex++;
                listIndex++;
            }
            // CSV or BOTH
            if (method != 1)
            {
                CreateCSVReport(rows);
            }
            // HTML or BOTH
            if (method != 0)
            {
                CreateHTMLReport(rows);
            }
        }

        /// GetHeaderString
        /// <summary>Create the string array for the header
        /// <para>Later can add more columns as needed</para></summary>
        /// <returns>headerStringArray - a string[] containing the header strings</returns>
        public static string[] GetHeaderString()
        {
            string[] headerStringArray = new string[7];
            headerStringArray[0] = "date";
            headerStringArray[1] = "url";
            headerStringArray[2] = "title";
            headerStringArray[3] = "desktop-score";
            headerStringArray[4] = "mobile-score";
            headerStringArray[5] = "desktop-overall-category";
            headerStringArray[6] = "mobile-overall-category";
            return headerStringArray;
        }

        /// CreateCSVReport
        /// <summary>
        /// <para>Takes in a multi-dimensional string array and creates a CSV
        /// file to contain it. Saves file to user's Downloads folder</para>
        /// </summary>
        /// <param name="data">multidimensional string array containing required data</param>
        public static void CreateCSVReport(string[,] data)
        {
            // Create CSV file name string using today's date & time
            string dateString = DateTime.Now.ToString("MMddyyyy-hhmmtt");
            string fileName = "PageSpeedCSVReport" + dateString + ".csv";
            string filePath = Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Downloads",fileName);
            using (CsvFileWriter writer = new CsvFileWriter(filePath))
            {
                for (int row = 0; row < data.GetLength(0); row++)
                {
                    CsvRow csvRow = new CsvRow();
                    for (int col = 0; col < data.GetLength(1); col++)
                    {
                        csvRow.Add(data[row, col]);
                    }
                    writer.WriteRow(csvRow);
                }
            }
        }

        /// CreateHTMLReport
        /// <summary>
        /// <para>Takes in a multi-dimensional string array and creates an html
        /// file to show it.</para>
        /// </summary>
        /// <param name="data">multidimensional string array containing required data</param>
        public static void CreateHTMLReport(string[,] data)
        {
            // get html text
            string htmlText = CreateHtmlPage(data);
            // prints html text
            // MessageBox.Show(htmlText, "Status Update", MessageBoxButtons.OK, MessageBoxIcon.Question);
            // initialize and start report viewer html page
            ReportHTMLViewer reportHTMLViewer = new ReportHTMLViewer(htmlText);
            reportHTMLViewer.Show();
        }

        /// CreateHtmlPage
        /// <summary>Create text for a HTML file.</summary>
        /// <param name="data">multidimensional string array containing required data</param>
        /// <returns>String containing text of a newly created HTML page.</returns>
        public static string CreateHtmlPage(string[,] data)
        {
            // create file string
            string htmlString = "<html><head><title>Dashboard Template for Page Speed Project</title>";
            // add bootstrap css
            htmlString += "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\">";
            htmlString += "</head><body><center><h1>Latest Page Speed Performance Report</h1></center>";
            htmlString += "<center><p>Generated on: <span id=\"headingDateString\"></span></p></center><hr><h2>Details:</h2>";
            htmlString += "<div class=\"table - responsive\">";
            // get table
            string htmlTable = CreateHTMLTable(data);
            htmlString += htmlTable;
            // close table div
            htmlString += "</div>";
            // add jquery script
            htmlString += "<script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"></script>";
            // js date func
            htmlString += "<script type=\"text/javascript\">var d = new Date(); document.getElementById(\"headingDateString\").innerHTML = d.toDateString();</script>";
            htmlString += "</body></html>";
            return htmlString;
        }

        /// CreateHTMLTable
        /// <summary>Create text for a HTML table.</summary>
        /// <param name="data">multidimensional string array containing required data</param>
        /// <returns>String containing text of a newly created HTML Table.</returns>
        public static string CreateHTMLTable(string[,] data)
        {
            HtmlTable table = new HtmlTable();
            table.Attributes.Add("class", "table table-striped table-sm");
            for (int row = 0; row < data.GetLength(0); row++)
            {
                HtmlTableRow rows = new HtmlTableRow();
                for (int col = 0; col < data.GetLength(1); col++)
                {
                    HtmlTableCell cell = new HtmlTableCell();
                    cell.InnerHtml = data[row, col];
                    cell.Align = "Center";
                    rows.Cells.Add(cell);
                }
                table.Rows.Add(rows);
            }
            StringWriter writer = new StringWriter();
            Html32TextWriter htmlWriter = new Html32TextWriter(writer);
            table.RenderControl(htmlWriter);
            string htmlTableString = writer.ToString();
            return htmlTableString;
        }
    }
}
